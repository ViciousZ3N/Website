** This is me playing around and testing with the javascript to create an interactive webpage **
